import React from "react";
import "./App.css";
// import Contacts from "./components/Contacts";
import Contactss from "./components/Contactss";
import Header from "./components/Header";

import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Header branding="Contact Manager" />
      <div className="container">
        <Contactss />
      </div>
    </div>
  );
}

export default App;
