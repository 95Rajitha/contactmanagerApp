import React, { Component } from "react";
import Contacts from "./Contacts";

class ContactList extends Component {
  state = {
    Contactss: [
      {
        id: 1,
        name: "john doe",
        email: "jdoe@gmail.com",
        phone: "222-222-222-222",
      },
      {
        id: 2,
        name: "karen elsmith",
        email: "karen@gmail.com",
        phone: "333-222-333-222",
      },
      {
        id: 3,
        name: "dwayne Birayn",
        email: "dwayne@gmail.com",
        phone: "222-222-222-222",
      },
    ],
  };

  deleteContact = (id) => {
    console.log("delete contact " + id + "> contactss");
    const { Contactss } = this.state;

    const newContactss = Contactss.filter((contactss) => contactss.id !== id);

    this.setState({
      Contactss: newContactss,
    });
  };

  render() {
    const { Contactss } = this.state;
    return (
      <React.Fragment>
        {Contactss.map((contact) => (
          <Contacts
            key={contact.id}
            contact={contact}
            deleteClickHandler={this.deleteContact.bind(this, contact.id)}
          />
        ))}
      </React.Fragment>
    );
  }
}
export default ContactList;
